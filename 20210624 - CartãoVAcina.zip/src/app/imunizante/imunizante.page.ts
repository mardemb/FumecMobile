import { Component, OnInit } from '@angular/core';
import { IImunizante }      from './../models/IImunizante.model';
@Component({
  selector: 'app-imunizante',
  templateUrl: './imunizante.page.html',
  styleUrls: ['./imunizante.page.scss'],
})
export class ImunizantePage implements OnInit {
  
  //public Id_Firebase: string;
  //public Id_Imunizante: number;

  public Imunizante: IImunizante =
  {
         Id_Firebase:                   ""
         ,Id_Imunizante:                 0
         ,Nome_Imunizante:              ""
         ,SEXO:                         ""
         ,Doses:                         0
         ,Idade_recomendada:            ""
         ,Intervalo_dose_recomendado:   ""
         ,Intervalo_dose_mínimo:        ""    
         ,Tipo_sanguineo:               []
         ,Observacao:                   ""
  };
  
  constructor() { console.log("aqui"); }

  ngOnInit() 
  {//this.Imunizante.Id_Firebase = "xxxx";
    this.Imunizante.Id_Firebase = "xxxxxxxxx";
    this.Imunizante.Id_Imunizante = 111;
    console.log("agora aqui");
  }

}
