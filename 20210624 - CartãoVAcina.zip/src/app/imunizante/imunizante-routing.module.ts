import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ImunizantePage } from './imunizante.page';

const routes: Routes = [
  {
    path: '',
    component: ImunizantePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ImunizantePageRoutingModule {}
