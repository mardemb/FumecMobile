import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ImunizantePageRoutingModule } from './imunizante-routing.module';

import { CabecalhoComponent }         from 'src/app/cabecalho/cabecalho.component';
import { RodapeCrudComponent }        from '../rodape-crud/rodape-crud.component';

import { ImunizantePage } from './imunizante.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImunizantePageRoutingModule
  ],
  declarations: [ImunizantePage
                ,CabecalhoComponent
                ,RodapeCrudComponent
              ]
})
export class ImunizantePageModule {}
