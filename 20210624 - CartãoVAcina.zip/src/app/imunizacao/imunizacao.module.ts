import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ImunizacaoPageRoutingModule } from './imunizacao-routing.module';
import { CabecalhoComponent } from 'src/app/cabecalho/cabecalho.component';
import { RodapeComponent } from 'src/app/rodape/rodape.component';
import { ImunizacaoPage } from './imunizacao.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImunizacaoPageRoutingModule
  ],
  declarations: [ImunizacaoPage, CabecalhoComponent, RodapeComponent]
})
export class ImunizacaoPageModule {}
