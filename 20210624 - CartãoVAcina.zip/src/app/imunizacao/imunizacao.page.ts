import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';

import { IImunizacao }  from './../models/IImunizacao.model';
// import { IImunizado }   from './../models/IImunizado.model';
// import { IImunizante }  from './../models/IImunizante.model';

import { SetIconInUseHeaderService } from './../services/set-iconi-in-use-header.service';

@Component({
  selector: 'app-imunizacao',
  templateUrl: './imunizacao.page.html',
  styleUrls: ['./imunizacao.page.scss'],
})
export class ImunizacaoPage implements OnInit {
  // public v_posicao_imagem = "../assets/imagens/Imunizacao.jpg";
  public v_posicao_imagem = "../assets/imagens/Contatos.jpg";
  public v_IconImagePath: string = "";
  public Imunizado = 
  [
       { 
         Id_imunizado: "1",
         Nome_imunizado: "Carlos Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "01/04/2021",
         Tipo_sanguineo: "A+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "2",
         Nome_imunizado: "Gilberto Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "25/03/2020",
         Tipo_sanguineo: "A-",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "3",
         Nome_imunizado: "João Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "07/02/2019",
         Tipo_sanguineo: "B+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "4",
         Nome_imunizado: "Ana Afonso da Silva",
         Data_nascimento_imunizado: "16/01/2018",
         Tipo_sanguineo: "B-",
         Sexo_imunizado: "F",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "5",
         Nome_imunizado: "Sofia Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "25/12/2017",
         Tipo_sanguineo: "O+",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "6",
         Nome_imunizado: "Eleonor Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "01/11/2016",
         Tipo_sanguineo: "O-",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "7",
         Nome_imunizado: "Gilberto Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "13/11/2016",
         Tipo_sanguineo: "AB+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "8",
         Nome_imunizado: "Clara Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "03/10/2015",
         Tipo_sanguineo: "AB-",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "9",
         Nome_imunizado: "João Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "03/10/2005",
         Tipo_sanguineo: "A+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "10",
         Nome_imunizado: "Pedro Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "03/10/1999",
         Tipo_sanguineo: "B+",
         Parentesco_imunizado: "Filho"
       }
  ];
  public Imunizante =
  [     {Id_Imunizante:               "1",
         Nome_Imunizante:             "BCG",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "1",
         Idade_recomendada:           "Ao nascer",
         Intervalo_dose_recomendado:  "",
         Intervalo_dose_mínimo:       "",
         Observacao:                  ""
        },
        {Id_Imunizante:               "2",
         Nome_Imunizante:             "HEPATITE B",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "1",
         Idade_recomendada:           "Ao nascer",
         Intervalo_dose_recomendado:  "",
         Intervalo_dose_mínimo:       "",
         Observacao:                  ""
        },
        {Id_Imunizante:               "3",
         Nome_Imunizante:             "POLIOMELITE VIP",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "3",
         Idade_recomendada:           ["2", "4",  "6"], /* meses */  
         Intervalo_dose_recomendado:  "60",             /* dias  */
         Intervalo_dose_mínimo:       "30",             /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "4",
         Nome_Imunizante:             "POLIOMELITE VOP",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "2",
         Idade_recomendada:           ["15", "48"], /* meses */  
         Intervalo_dose_recomendado:  "60",         /* dias  */
         Intervalo_dose_mínimo:       "30",         /* dias  */
         Observacao:                  "",
        },
        {Id_Imunizante:               "5",
         Nome_Imunizante:             "ROTAVIRUS",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "2",
         Idade_recomendada:           ["2", "4"], /* meses */  
         Intervalo_dose_recomendado:  "60",       /* dias  */
         Intervalo_dose_mínimo:       "30",        /* dias  */
         Observacao:                  "",
        },
        {Id_Imunizante:               "6",
         Nome_Imunizante:             "DTB+Hib+HB",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "3",
         Idade_recomendada:           ["2", "4", "6"], /* meses */  
         Intervalo_dose_recomendado:  "60",            /* dias  */
         Intervalo_dose_mínimo:       "30",             /* dias  */
         Observacao:                  "",
        },
        {Id_Imunizante:               "7",
         Nome_Imunizante:             "PNEUMOCÓCICA 10 VALENTE",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "3",
         Idade_recomendada:           ["2", "4", "12"], /* meses */  
         Intervalo_dose_recomendado:  "60",             /* dias  */
         Intervalo_dose_mínimo:       "30",             /* dias  */
         Observacao:                  "",
        },
        {Id_Imunizante:               "8",
         Nome_Imunizante:             "MENINGOCÓCICA C CONJUGADA",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "3",
         Idade_recomendada:           ["3", "5", "12"],  /* meses */  
         Intervalo_dose_recomendado:  "",                /* dias  */
         Intervalo_dose_mínimo:       "30",              /* dias  */
         Observacao:                  "",
        },
        {Id_Imunizante:               "9",
         Nome_Imunizante:             "FEBRE AMARELA",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "2",
         Idade_recomendada:           ["9", "48"],       /* meses */  
         Intervalo_dose_recomendado:  "",                /* dias  */
         Intervalo_dose_mínimo:       "30",              /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "10",
         Nome_Imunizante:             "SCR - SARAMPO, CAXUMBA E RUBEOLA",
         SEXO:                        "A",              /* AMBOS */
         Doses:                       "2",
         Idade_recomendada:           ["12"],           /* meses */  
         Intervalo_dose_recomendado:  "",               /* dias  */
         Intervalo_dose_mínimo:       "30",             /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "11",
         Nome_Imunizante:             "HA - HEPATITE A",
         SEXO:                        "A",                      /* AMBOS */
         Doses:                       "1",
         Idade_recomendada:           ["15"],                   /* meses */  
         Intervalo_dose_recomendado:  "",                       /* dias  */
         Intervalo_dose_mínimo:       "",                       /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "12",
         Nome_Imunizante:             "DTP - DIFTERIA, TÉTANO E PERTUSSIS (COQUELUXE)",
         SEXO:                        "A",                       /* AMBOS */
         Doses:                       "5",
         Idade_recomendada:           ["6","9","15","36","48"],  /* meses */  
         Intervalo_dose_recomendado:  "",                        /* dias  */
         Intervalo_dose_mínimo:       "",                        /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "13",
         Nome_Imunizante:             "DT - DIFTERIA, TÉTANO",
         SEXO:                        "A",                       /* AMBOS */
         Doses:                       "3",
         Idade_recomendada:           ["82","120","120"],        /* meses */  
         Intervalo_dose_recomendado:  "60",                      /* dias  */
         Intervalo_dose_mínimo:       "30",                       /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "14",
         Nome_Imunizante:             "HPV - PAPILONAVIRUS HUMANO",
         SEXO:                        "F",                        /* FEMININO */
         Doses:                       "2",
         Idade_recomendada:           ["108","168"],              /* meses */  
         Intervalo_dose_recomendado:  "6",                        /* meses  */
         Intervalo_dose_mínimo:       "",                         /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "15",
         Nome_Imunizante:             "HPV - PAPILONAVIRUS HUMANO",
         SEXO:                        "M",                        /* MASCULINO */
         Doses:                       "2",
         Idade_recomendada:           ["132","168"],              /* meses */  
         Intervalo_dose_recomendado:  "6",                        /* meses  */
         Intervalo_dose_mínimo:       "",                          /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "16",
         Nome_Imunizante:             "VARICELA",
         SEXO:                        "A",                        /* AMBOS */
         Doses:                       "1",
         Idade_recomendada:           ["48"],                     /* meses */  
         Intervalo_dose_recomendado:  "",                         /* meses  */
         Intervalo_dose_mínimo:       "30",                       /* dias  */
         Observacao:                  ""
        },
        {Id_Imunizante:               "17",
         Nome_Imunizante:             "INFLUENZA",
         SEXO:                        "A",                          /* AMBOS */
         Doses:                       "X",
         Idade_recomendada:           ["0"],                        /* meses */  
         Intervalo_dose_recomendado:  "12",                         /* meses  */
         Intervalo_dose_mínimo:       "",                           /* dias  */
         Observacao:                  "Intervalo de 6 meses para menores de 6 anos"
        },
  ];

  public Imunizacao =  
  [
    {Id_Imunizado:    "1",
     Id_Imunizante:   "1",
     Data_imunizacao: "15/04/2021",
     Dose:            "1"
    },
    {Id_Imunizado:    "1",
     Data_imunizacao: "15/04/2021",
     vacina:          "BCG",
     Dose:            "1"
    },
  ]
  public Tipo_sanguineo = ["A+","B+","A-","B-","O+","O-","AB+","AB-"];
    
  /* constructor(private rotaativa:ActivatedRoute, private  v_SetIconInUseHeaderService:  SetIconInUseHeaderService) { }

  ngOnInit() { 
       
       let  var1 = Number(this.rotaativa.snapshot.paramMap.get('v_index'));
       this.v_IconImagePath = this.v_SetIconInUseHeaderService.getIconImagePath(var1);
  }
*/
constructor() { }
ngOnInit() { }
}

