import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';

import { IImunizado }      from './../models/IImunizado.model';
import { Iglobal }          from "../models/Iglobal.model"

@Component({
  selector: 'app-imunizado',
  templateUrl: './imunizado.page.html',
  styleUrls: ['./imunizado.page.scss'],
})
export class ImunizadoPage implements OnInit {
       
       public iglobal: Iglobal = {v_crud_imunizado:    0
                                 ,v_login_name:       ""
                                 ,v_index:             0
                                 ,v_pageinuse:        ""
                                 ,v_iconimagepath:    ""
                                 };
       public v_index_crud: number;
       public v_pageInUse: string;
       public v_ligado: boolean = false;
       public Imunizado = 
  [
       { 
         Id_imunizado: "1",
         Nome_imunizado: "Carlos Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "01/04/2021",
         Tipo_sanguineo: "A+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "2",
         Nome_imunizado: "Gilberto Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "25/03/2020",
         Tipo_sanguineo: "A-",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "3",
         Nome_imunizado: "João Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "07/02/2019",
         Tipo_sanguineo: "B+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "4",
         Nome_imunizado: "Ana Afonso da Silva",
         Data_nascimento_imunizado: "16/01/2018",
         Tipo_sanguineo: "B-",
         Sexo_imunizado: "F",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "5",
         Nome_imunizado: "Sofia Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "25/12/2017",
         Tipo_sanguineo: "O+",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "6",
         Nome_imunizado: "Eleonor Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "01/11/2016",
         Tipo_sanguineo: "O-",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "7",
         Nome_imunizado: "Gilberto Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "13/11/2016",
         Tipo_sanguineo: "AB+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "8",
         Nome_imunizado: "Clara Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "03/10/2015",
         Tipo_sanguineo: "AB-",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "9",
         Nome_imunizado: "João Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "03/10/2005",
         Tipo_sanguineo: "A+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "10",
         Nome_imunizado: "Pedro Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "03/10/1999",
         Tipo_sanguineo: "B+",
         Parentesco_imunizado: "Filho"
       }
  ];
      public v_NomeImunizado: string;
      public v_array_crud: boolean[] = [false, false, false, false, false];
      public v_cont: number;
      constructor( ) 
                 {console.log('Modulo: imunizado.page.ts in constructor');
                  this.v_pageInUse = "IMUNIZADO"
                  console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
                             ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
                             ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
                             ," v_INDEX: "      , globalThis.v_INDEX);
                  globalThis.v_PAGEINUSE = "Imunizado";
                  this.v_pageInUse       = globalThis.v_PAGEINUSE;
                 }
      ngOnInit() {console.log('Modulo: imunizado.page.ts in ngOnInit')
                  this.v_pageInUse = "IMUNIZADO";
                  console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
                 ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
                 ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
                 ," v_INDEX: "      , globalThis.v_INDEX
                 ," v_INDEX_CRUD: "  ,globalThis.v_INDEX_CRUD
                 , "v_Array: ", this.v_array_crud);
                 if (globalThis.v_INDEX_CRUD != 9) 
                    {
                     globalThis.v_ARRAY_CRUD [globalThis.v_INDEX_CRUD] = true;
                     this.v_array_crud[globalThis.v_INDEX_CRUD] = globalThis.v_ARRAY_CRUD [globalThis.v_INDEX_CRUD]
                    }
                 this.v_cont = globalThis.v_CONT;
                 console.log(" v_array_crud: "
                            , globalThis.v_ARRAY_CRUD[globalThis.v_INDEX_CRUD]
                            ," v_cont: ", this.v_cont);
                 }
}
