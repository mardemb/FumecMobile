import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ImunizadoPage } from './imunizado.page';

const routes: Routes = [
  {
    path: '',
    component: ImunizadoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ImunizadoPageRoutingModule {}
