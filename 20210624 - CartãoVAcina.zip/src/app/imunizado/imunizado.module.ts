import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ImunizadoPageRoutingModule } from './imunizado-routing.module';
import { CabecalhoComponent }         from 'src/app/cabecalho/cabecalho.component';
import { RodapeComponent }            from 'src/app/rodape/rodape.component';
import { RodapeCrudComponent }        from '../rodape-crud/rodape-crud.component';
import { CriarImunizado}              from '../criar-imunizado/criarImunizado.component';
import { ListarImunizadoComponent}    from '../listar-imunizado/listar-imunizado.component';
import { ImunizadoPage }              from './imunizado.page';

@NgModule({
  imports: [CommonModule
           ,FormsModule
           ,IonicModule
           ,ImunizadoPageRoutingModule
//           ,CriarImunizado
  ],
  declarations: [ImunizadoPage
                ,CabecalhoComponent
                ,RodapeComponent
                ,RodapeCrudComponent
                ,CriarImunizado
                ,ListarImunizadoComponent
                ]
})
export class ImunizadoPageModule {}
