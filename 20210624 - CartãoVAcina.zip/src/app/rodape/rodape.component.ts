import { Component, OnInit } from '@angular/core';
import { Router}             from '@angular/router';
import { ActivatedRoute }    from '@angular/router';

@Component({
  selector: 'app-rodape',
  templateUrl: './rodape.component.html',
  styleUrls: ['./rodape.component.scss'],
})
export class RodapeComponent implements OnInit {
  
       public v_login_name="zégotinha" ;
       public v_index = 0;
       public v_index_crud;
       public v_pageInUse="";
       constructor(private  rotaativa:ActivatedRoute, 
                   private  rota: Router) 
                  {console.log("Módulo: rodape.component.ts in constructor");
                   console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
                             ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
                             ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
                             ," v_INDEX: "      , globalThis.v_INDEX
                             ," v_INDEX:_CRUD " , globalThis.v_INDEX_CRUD);
                  }

      ngOnInit() {console.log("Módulo: rodape.component.ts in ngOnInit");
                   console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
                              ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
                              ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
                              ," v_INDEX: "      , globalThis.v_INDEX
                              ," v_INDEX_CRUD: " , globalThis.v_INDEX_CRUD);
                    this.v_index     = globalThis.v_INDEX;
                    this.v_pageInUse = globalThis.v_PAGEINUSE;
                    this.v_index_crud     = globalThis.v_INDEX_CRUD;
                  }

      VaiParaImunizado() 
          {
           console.log('Método: VaiParaImunizado, in the RodapeComponent class, in the Modulo: rodape.component.ts ');
           this.v_index=2;
           console.log("v_pageInUse: ", this.v_pageInUse, " v_index_crud: ", this.v_index_crud
                       ,"v_index ", this.v_index);
           this.v_pageInUse = "Imunizado"
           this.rota.navigate([this.v_pageInUse
                              ,this.v_index
                              ,this.v_login_name
                              ,this.v_index_crud
                              ]); 
          //this.rota.navigate(['imunizado']);                              
          };

      VaiParaImunizante() 
          {
           console.log('Modulo: rodape.component.ts in VaiParaImunizante of the RodapeComponent class');
           this.v_index=3;
           console.log('v_index: ', this.v_index,' v_login_name: ', this.v_login_name)
           console.log("v_index_crud: ", this.v_index_crud);
           this.rota.navigate(['Imunizante'
                              ,this.v_index
                              ,this.v_login_name
                              ,this.v_index_crud
                              ]); 
//           this.rota.navigate(['/Imunizado']);
          };
}
