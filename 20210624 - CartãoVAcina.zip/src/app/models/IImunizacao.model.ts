export interface IImunizacao {
       Id_Imunizado:     number,
       Id_Imunizante:    string,
       Data_imunizacao:  string,
       Dose:             string
}