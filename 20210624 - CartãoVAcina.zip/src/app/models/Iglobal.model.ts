export interface Iglobal 
      {v_crud_imunizado:  number;
       v_login_name:      string;
       v_index:           number;
       v_pageinuse:       string;
       v_iconimagepath:   string;
      }