export interface IImunizado {
         Id_Firebase:                String;
         Id_imunizado:              number,
         Nome_imunizado:            string,
         Sexo_imunizado:            string,
         Data_nascimento_imunizado: string,
         Tipo_sanguineo_imunizado:  Array<string>,
         Parentesco_imunizado:      string,
         Idade_imunizado:           Array<number>
         }
