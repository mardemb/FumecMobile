export interface IImunizante {
       Id_Firebase:                 string;
       Id_Imunizante:               number,
       Nome_Imunizante:             string,
       SEXO:                        string,        
       Doses:                       number,
       Idade_recomendada:           string,
       Intervalo_dose_recomendado:  string,
       Intervalo_dose_mínimo:       string,
       Tipo_sanguineo:              [],
       Observacao:                  string
}