import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { SetIconInUseHeaderService } from './../services/set-iconi-in-use-header.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
   public v_pageInUse: string;
   constructor( ) 
              {globalThis.v_PAGEINUSE = "Home";
               this.v_pageInUse       = globalThis.v_PAGEINUSE;
               globalThis.v_INDEX_CRUD = 9;
               globalThis.v_CONT = 0;
               console.log("Módulo: home.page.ts in constructor")
               console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
               ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
               ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
               ," v_INDEX: "      , globalThis.v_INDEX
               ," v_INDEX_CRUD: "      , globalThis.v_INDEX_CRUD);
               globalThis.v_ARRAY_CRUD = [false, false, false, false, false];
              }                                  
  
  onClick() { }
}
