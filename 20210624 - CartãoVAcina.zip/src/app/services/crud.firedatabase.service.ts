import { Injectable }                       from '@angular/core';
import { AngularFirestore
        ,AngularFirestoreCollection
        ,AngularFirestoreModule }            from '@angular/fire/firestore';

import { IImunizado }                        from './../models/IImunizado.model';

@Injectable({
  providedIn: 'root'
})
export class CrudFiredatabaseService {

  constructor(private firestore: AngularFirestore) { }

  public imunizados: Array<IImunizado> = [];
  public imunizado:        IImunizado;

  public readImunizados() 
         {return this.firestore.collection('IMUNIZADO').snapshotChanges();
         }
  public ListAll() // Método que devolve uma collection de "Imunizados"
         {return this.firestore.collection('IMUNIZADO').snapshotChanges();
         }
}
