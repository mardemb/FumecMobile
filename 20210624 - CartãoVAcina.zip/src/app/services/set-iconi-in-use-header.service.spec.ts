import { TestBed } from '@angular/core/testing';

import { SetIconInUseHeaderService } from './set-iconi-in-use-header.service';

describe('SetIconiInUseHeaderService', () => {
  let service: SetIconInUseHeaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SetIconInUseHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
