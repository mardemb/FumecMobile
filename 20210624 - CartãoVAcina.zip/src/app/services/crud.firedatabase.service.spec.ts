import { TestBed } from '@angular/core/testing';

import { Crud.FiredatabaseService } from './crud.firedatabase.service';

describe('Crud.FiredatabaseService', () => {
  let service: Crud.FiredatabaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Crud.FiredatabaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
