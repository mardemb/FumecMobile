import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SetIconInUseHeaderService {

  // public pageInUse: string ="";
  public ArrayPageNameInUse = ["login"
                              ,"Home"
                              ,"Imunizado"
                              ,"Imunizante"
                              ,"Imunizacao"
                              ,"CheckListImunizacao"
                              ,"CalendarioImunizacao"
                              ];

  public ArrayFileIconsImages = ["../assets/imagens/login.png"
                                ,"../assets/imagens/home.png"  
                                ,"../assets/icon/man-outline.svg"
                                ,"../assets/icon/20210509-VACINA_01.png"
                                ,"../assets/imagens/Imunizacao.jpg"
                                ,"../assets/imagens/CheckListImunizacao.jpg"
                                ,"../assets/icon/calendar-outline.svg"
                                ];

  constructor() { }

  public getIconImagePath( v_index: number): string {
//       console.log("GetIconImagePath: " + v_index);
         return this.ArrayFileIconsImages[v_index];
  }

  public getNamePageInUse( v_index: number): string {
         return this.ArrayPageNameInUse[v_index];
  }
}
