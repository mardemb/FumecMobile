import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  //{
  //  path: 'home',
  //  loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  //},
  {
    path: '',
    redirectTo: 'Login',
    pathMatch: 'full'
  },
  {
    path: 'Home/:v_index/:v_login_name/:v_index_crud',
   loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'imunizacao/:v_index/:v_login_name',
    loadChildren: () => import('./imunizacao/imunizacao.module').then( m => m.ImunizacaoPageModule)
  },
  {
    path: 'Imunizado/:v_index/:v_login_name/:v_index_crud',
    //path: 'imunizado',
    loadChildren: () => import('./imunizado/imunizado.module').then( m => m.ImunizadoPageModule)
  },
  {
    path: 'Imunizante/:v_index/:v_login_name/:v_index_crud',
    loadChildren: () => import('./imunizante/imunizante.module').then( m => m.ImunizantePageModule)
  },
  {
    path: 'Login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {  }
