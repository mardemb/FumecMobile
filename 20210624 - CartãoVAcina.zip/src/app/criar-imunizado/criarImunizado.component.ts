import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-criar-imunizado',
  templateUrl: './criarImunizado.component.html',
  styleUrls: ['./criarImunizado.component.scss'],
})
export class CriarImunizado implements OnInit {
  
  public v_pageInUse = "";

  constructor() { }

  ngOnInit() {console.log("Módulo: criarImunizado.component.ts in ngOnInit");
              this.v_pageInUse = globalThis.v_PAGEINUSE;
              console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
                         ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
                         ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
                         ," v_INDEX: "      , globalThis.v_INDEX
                         ," v_INDEX_CRUD: " , globalThis.v_INDEX_CRUD
                         ,"v_pageInUse: "   ,   this.v_pageInUse);
  }

}
