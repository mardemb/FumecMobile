import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { SetIconInUseHeaderService } from './../services/set-iconi-in-use-header.service';

@Component({
  selector: 'app-cabecalho',
  templateUrl: './cabecalho.component.html',
  styleUrls: ['./cabecalho.component.scss'],
})
export class CabecalhoComponent implements OnInit 
{
  //@Input() img: any;
  public v_pageInUse = ""
  public v_IconImagePath: string ="";
  public v_page_login: boolean;
  public v_nao_page_login: boolean;
  public v_login_name: string = "";
  public v_index_crud: number;
  
  constructor(private  rotaativa:ActivatedRoute 
             ,private  v_SetIconInUseHeaderService:  SetIconInUseHeaderService) { };

  ngOnInit() { 
        
        console.log("Módulo: cabecalho.component.ts in ngOnInit")
        let  var1                    = Number( this.rotaativa.snapshot.paramMap.get('v_index'));
        this.v_login_name            = this.rotaativa.snapshot.paramMap.get('v_login_name');
        this.v_index_crud            = Number(this.rotaativa.snapshot.paramMap.get('v_index_crud'));
        this.v_IconImagePath         = this.v_SetIconInUseHeaderService.getIconImagePath(var1);
        this.v_pageInUse             = this.v_SetIconInUseHeaderService.getNamePageInUse(var1);

        globalThis.v_LOGIN_NAME      = this.v_login_name;
        globalThis.v_PAGEINUSE       = this.v_pageInUse;
        globalThis.v_ICONIMAGEPATH   = this.v_IconImagePath;
        globalThis.v_INDEX           = var1;
        globalThis.v_INDEX_CRUD      = this.v_index_crud;

        console.log("GLOBALS - NAME: ", globalThis.v_LOGIN_NAME
                   ," PAGEINUSE: "    , globalThis.v_PAGEINUSE
                   ," ICONIMAGEPATH: ", globalThis.v_ICONIMAGEPATH
                   ," v_INDEX: "      , globalThis.v_INDEX
                   ," v_INDEX_CURD: " , globalThis.v_INDEX_CRUD)
        
        if (var1 === 0) {
            this.v_page_login = true;
            this.v_nao_page_login = false;
           }
        else {this.v_page_login = false;
              this.v_nao_page_login = true;
             }
  }
         
}

