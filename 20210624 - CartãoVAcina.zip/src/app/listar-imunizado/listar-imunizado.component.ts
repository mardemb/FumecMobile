import { Component, OnInit }       from '@angular/core';
import { CrudFiredatabaseService } from './../services/crud.firedatabase.service';
import { IImunizado }              from './../models/IImunizado.model';
@Component({
  selector: 'app-listar-imunizado',
  templateUrl: './listar-imunizado.component.html',
  styleUrls: ['./listar-imunizado.component.scss'],
})
export class ListarImunizadoComponent implements OnInit {
       public imunizados: Array<IImunizado> = [ ];
      public Imunizado = 
  [
       { 
         Id_imunizado: "1",
         Nome_imunizado: "Carlos Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "01/04/2021",
         Tipo_sanguineo: "A+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "2",
         Nome_imunizado: "Gilberto Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "25/03/2020",
         Tipo_sanguineo: "A-",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "3",
         Nome_imunizado: "João Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "07/02/2019",
         Tipo_sanguineo: "B+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "4",
         Nome_imunizado: "Ana Afonso da Silva",
         Data_nascimento_imunizado: "16/01/2018",
         Tipo_sanguineo: "B-",
         Sexo_imunizado: "F",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "5",
         Nome_imunizado: "Sofia Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "25/12/2017",
         Tipo_sanguineo: "O+",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "6",
         Nome_imunizado: "Eleonor Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "01/11/2016",
         Tipo_sanguineo: "O-",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "7",
         Nome_imunizado: "Gilberto Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "13/11/2016",
         Tipo_sanguineo: "AB+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "8",
         Nome_imunizado: "Clara Afonso da Silva",
         Sexo_imunizado: "F",
         Data_nascimento_imunizado: "03/10/2015",
         Tipo_sanguineo: "AB-",
         Parentesco_imunizado: "Filha"
       },
       { Id_imunizado: "9",
         Nome_imunizado: "João Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "03/10/2005",
         Tipo_sanguineo: "A+",
         Parentesco_imunizado: "Filho"
       },
       { Id_imunizado: "10",
         Nome_imunizado: "Pedro Afonso da Silva",
         Sexo_imunizado: "M",
         Data_nascimento_imunizado: "03/10/1999",
         Tipo_sanguineo: "B+",
         Parentesco_imunizado: "Filho"
       }
  ];

  constructor(private crudFireDatabase: CrudFiredatabaseService) {  }
  ngOnInit() {console.log("Classe ListarImunizadoComponent in ngOnInit");
              globalThis.v_CONT = globalThis.v_CONT + 1;
              console.log("v_CONT: "       , globalThis.v_CONT
                         ," v_ARRAY_CRUD: ", globalThis.v_ARRAY_CRUD);
              this.crudFireDatabase.ListAll().subscribe(
                   (imunizados)=>{console.log('Resposta crudFireDatabase: ', imunizados);
                                  this.imunizados = imunizados.map( (obj)=>
                                  {return {Id_Firebase:    obj.payload.doc.id
                                          ,Id_imunizado:   obj.payload.doc.data()['Id_Imunizado']
                                          ,Nome_imunizado: obj.payload.doc.data()['Nome_Imunizado']
                                          ,Sexo_imunizado: obj.payload.doc.data()['Sexo_Imunizado']
                                          ,Data_nascimento_imunizado:
                                           obj.payload.doc.data()['Data_nascimento_Imunizado']
                                          ,Tipo_sanguineo_imunizado:
                                           obj.payload.doc.data()['Tipo_sanguineo_Imunizado']
                                          ,Parentesco_imunizado:
                                           obj.payload.doc.data()['Parentesco_Imunizado']
                                          ,Idade_imunizado:
                                           obj.payload.doc.data()['Idade_Imunizado']
                                          }
                                 })

                                }
                     );
              // console.log('Imunizados.page: ', obj);
  }

}
