import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { LoginPage } from './login.page';

import { LoginPageRoutingModule } from './login-routing.module';
import { CabecalhoComponent } from 'src/app/cabecalho/cabecalho.component';
import { RodapeComponent } from 'src/app/rodape/rodape.component';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LoginPageRoutingModule
  ],
  declarations: [LoginPage, CabecalhoComponent, RodapeComponent]
})
export class LoginPageModule {  }