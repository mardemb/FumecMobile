import { Component }   from '@angular/core';
import { Router }      from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'login.page.html',
  styleUrls: ['login.page.scss'],
})
export class LoginPage {
    
  public v_msg_erro = ""; 
  public v_login_default="zégotinha";
  public v_login_name="zégotinha" ;
  public v_psw_default="12345";
  public v_psw="12345";
  public v_index = 1;
  public v_index_crud = 9;
  public v_pageInUse: string;
  
  constructor(private rota: Router) 
  { console.log("Módulo: login.page.ts in constructor");
    this.v_msg_erro="Iniciando o módulo";
    globalThis.v_PAGEINUSE = "Login";
    this.v_pageInUse       = globalThis.v_PAGEINUSE;
  }                                  
  
  public  f_verifica_login()
    { 
      if (this.v_login_default != this.v_login_name) {
          console.log("login name: " + this.v_login_name);
          this.v_msg_erro ="Login inexistente";
        }
      else
          this.v_msg_erro = "";
    }
    
  public  f_verifica_psw() 
    {if (this.v_psw_default != this.v_psw) 
         this.v_msg_erro ="Senha inválida";
    }
  onClick()
    {this.f_verifica_login();
     if (!(this.v_msg_erro))
           this.f_verifica_psw();
     if (!(this.v_msg_erro))
           this.v_pageInUse="Home"
           this.rota.navigate(['/'+this.v_pageInUse, this.v_index,this.v_login_name,this.v_index_crud]);
    }
}
