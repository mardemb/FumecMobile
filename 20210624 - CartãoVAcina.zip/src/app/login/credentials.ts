export const firebaseConfig = {
    apiKey: "AIzaSyAMOermUga0R4Q9Dyn3Pd6cpYFxekUbvVQ",
    authDomain: "cartao-de-vacina.firebaseapp.com",
    projectId: "cartao-de-vacina",
    storageBucket: "cartao-de-vacina.appspot.com",
    messagingSenderId: "432616924771",
    appId: "1:432616924771:web:5441cfdf3895f706eaba56",
    measurementId: "G-0J1HXEKEND"
  };