import { Component, OnInit } from '@angular/core';
import { Router}             from '@angular/router';

import { CrudFiredatabaseService } from './../services/crud.firedatabase.service';
import {  IImunizado}               from './../models/IImunizado.model';

@Component({
  selector: 'app-rodape-crud',
  templateUrl: './rodape-crud.component.html',
  styleUrls: ['./rodape-crud.component.scss'],
})
export class RodapeCrudComponent implements OnInit {

  public v_login_name:  string;
  public v_index:       number;
  public v_index_crud:  number;
  public v_pageInUse:   string;

  public Imunizados: Array<IImunizado> = [];

  constructor(private  rota: Router, private fdtbs: CrudFiredatabaseService) 
        {console.log('Modulo: rodape-crud.components.ts in constructor');
         console.log("GLOBALS - NAME: "   ,globalThis.v_LOGIN_NAME
                    ," PAGEINUSE: "       ,globalThis.v_PAGEINUSE
                    ," ICONIMAGEPATH: "   ,globalThis.v_ICONIMAGEPATH
                    ," v_INDEX: "         ,globalThis.v_INDEX
                    ," v_INDEX_CRUD: "    ,globalThis.v_INDEX_CRUD)
        }

  ngOnInit() {console.log('Modulo: rodape-crud.components.ts in ngOnInit');
              console.log("GLOBALS - NAME: ",globalThis.v_LOGIN_NAME
              ," PAGEINUSE: "               ,globalThis.v_PAGEINUSE
              ," ICONIMAGEPATH: "           ,globalThis.v_ICONIMAGEPATH
              ," v_INDEX: "                 ,globalThis.v_INDEX
              ," v_INDEX_CRUD: "            ,globalThis.v_INDEX_CRUD)
              this.v_login_name    = globalThis.v_LOGIN_NAME;
              this.v_index         = globalThis.v_INDEX;
              this.v_pageInUse     = globalThis.v_PAGEINUSE;   
              this.v_pageInUse = '/' + this.v_pageInUse;
              this.v_index_crud = globalThis.v_INDEX_CRUD;
             };

  Criar() 
        {console.log('Método: Criar da Classe RodapeCrudComponent no módulo rodape-crud.component.ts');
        
        console.log('v_pageInUse: '
                    ,this.v_pageInUse
                    ,'v_index: '
                    ,this.v_index
                    ,'v_login_name: '
                    ,this.v_login_name
                    ,'v_index_crud: ', this.v_index_crud);
        this.v_index_crud = 0;
        globalThis.v_INDEX_CRUD=this.v_index_crud;
        this.rota.navigate([this.v_pageInUse
                               ,this.v_index
                               ,this.v_login_name
                               ,this.v_index_crud
                               ]);
        }

  Listar() 
        {console.log('Método: Listar da Classe RodapeCrudComponent no módulo rodape-crud.component.ts');
        console.log('v_index: '
                    ,this.v_index
                    ,'v_login_name: '
                    ,this.v_login_name
                    ,'v_index_crud: '
                    , this.v_index_crud
                    ,'v_pageInUse: '
                    ,this.v_pageInUse
                    );
        this.v_index_crud = 3;
        globalThis.v_INDEX_CRUD=this.v_index_crud;
        this.rota.navigate([this.v_pageInUse
                           ,this.v_index
                           ,this.v_login_name
                           ,this.v_index_crud
                           ]);
        }
}
