export let v_msg_erro:        string;
export let v_login_default:   string;
export let v_psw_default:     string;
export let v_psw:             string;
