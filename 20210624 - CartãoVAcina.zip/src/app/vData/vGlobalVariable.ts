
declare var  v_INDEX_CRUD:      number;
declare var  v_LOGIN_NAME:      string;
declare var  v_INDEX:           number;
declare var  v_PAGEINUSE:       string;
declare var  v_ICONIMAGEPATH:   string;
declare var  v_ARRAY_CRUD: boolean [];
declare var  v_CONT: number;